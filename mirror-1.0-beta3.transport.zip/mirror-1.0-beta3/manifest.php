<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '--------------------
Plugin: Mirror
--------------------
Version: 1.0-beta2

Synchronizes elements from filesystem with database.',
    'changelog' => 'Changelog file for Mirror plugin.

Mirror 1.0-beta1
====================================
- First release

Mirror 1.0-beta2
====================================
- Added checking of static elements support
- Added internationalization support',
    'setup-options' => 'mirror-1.0-beta3/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '6ee7849d55638b928562286cfbc90ddf',
      'native_key' => 'mirror',
      'filename' => 'modNamespace/b8301788e1224ef090f6e58377dfffb7.vehicle',
      'namespace' => 'mirror',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'b87ba69cbc2d2f6019bd49449f40312f',
      'native_key' => 1,
      'filename' => 'modPlugin/e9e6a84b7d4ed0e372cd6d9b9aa95315.vehicle',
      'namespace' => 'mirror',
    ),
  ),
);