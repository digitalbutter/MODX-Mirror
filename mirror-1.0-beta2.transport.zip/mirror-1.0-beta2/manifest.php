<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '--------------------
Plugin: Mirror
--------------------
Version: 1.0-beta2

Synchronizes elements from filesystem with database.',
    'changelog' => 'Changelog file for Mirror plugin.

Mirror 1.0-beta1
====================================
- First release

Mirror 1.0-beta2
====================================
- Added checking of static elements support
- Added internationalization support',
    'setup-options' => 'mirror-1.0-beta2/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '2ddf1c94bf59f4bcba67a53e22ae89d8',
      'native_key' => 'mirror',
      'filename' => 'modNamespace/f898c9db776e500da7ee3b8f45228817.vehicle',
      'namespace' => 'mirror',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '7d19c79683d6482dee8c821a69b50487',
      'native_key' => 1,
      'filename' => 'modPlugin/95b2b8c6ae74be07adbed78a69c3f05b.vehicle',
      'namespace' => 'mirror',
    ),
  ),
);