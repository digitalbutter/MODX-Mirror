--------------------
Plugin: Mirror
--------------------
Version: 1.0-beta2

Synchronizes elements from filesystem with database.